package com.kotlin.mall.common

//首页banner

const val HOME_BANNER_ONE = "http://contentcms-bj.cdn.bcebos.com/cmspic/af7d092d2f419406d3fa1328ba710cd4.jpeg?x-bce-process=image/crop,x_0,y_0,w_930,h_506"

const val HOME_BANNER_TWO = "http://contentcms-bj.cdn.bcebos.com/cmspic/435e3e4b46eea19b2a7ac2a68101fb04.jpeg?x-bce-process=image/crop,x_0,y_0,w_900,h_489"

const val HOME_BANNER_THREE = "http://contentcms-bj.cdn.bcebos.com/cmspic/d8b2fe1d5070143e4a37e88c5b177e5b.jpeg?x-bce-process=image/crop,x_0,y_0,w_899,h_489"