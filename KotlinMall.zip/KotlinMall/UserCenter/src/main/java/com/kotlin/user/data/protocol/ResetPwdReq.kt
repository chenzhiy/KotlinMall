package com.kotlin.user.data.protocol

data class ResetPwdReq(val mobile:String, val pwd:String)