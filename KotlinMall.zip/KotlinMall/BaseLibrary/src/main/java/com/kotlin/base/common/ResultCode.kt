package com.kotlin.base.common


class ResultCode {
    companion object{
        const val SUCCESS = 0
    }
}