package com.kotlin.base.ext

class BaseException(val status:Int,val msg:String):Throwable() {
}