package com.kotlin.base.ui.fragment

import androidx.appcompat.app.AppCompatActivity
import com.trello.rxlifecycle.components.support.RxAppCompatActivity
import com.trello.rxlifecycle.components.support.RxFragment

open class BaseFragment: RxFragment() {
}